#ifndef VIEW_H
#define VIEW_H

#include "type.h"      


typedef struct _TagInfo
{
    FILE* fptr_mp3;
    char frame_Id [4];

    char* title_tag;
    uint title_tag_size;

    char* artist_tag;
    uint artist_tag_size;

    char* album_tag;
    uint album_tag_size;

    char* year;
    uint year_size;

    char* content_type;
    uint content_type_size;

    char* comments;
    uint comment_size;

} TagInfo;

OperationType check_operation (char* argv[]);
Status read_and_validate_mp3_file (char* argv[], TagInfo* mp3tagInfo);
Status view_tag (char* argv[], TagInfo* mp3tagInfo);
Status get_and_display_data (const char* str_frame, const char* str_Id, char* frame_Id, uint* tag_size, char* tag, FILE* fptr);

#endif
